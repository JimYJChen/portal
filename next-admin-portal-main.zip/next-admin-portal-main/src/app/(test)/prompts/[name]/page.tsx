// pages/index.tsx
import { PromptManagementPage } from "./test"

interface PageProps {
    serverPermissions: string[]; // 服务端注入的权限数据
}

const HomePage: React.FC<PageProps> = async ({ serverPermissions }) => {
    // const [clientPermissions, setClientPermissions] = useState<string[]>([]);
    const response = await fetch("http://localhost:3000/api/permissions");
    const data = await response.json();
    console.log(data)
    // // 客户端动态获取权限（示例：模拟实时更新）
    // useEffect(() => {
    //     const fetchClientPermissions = async () => {
    //         const res = await fetch('/api/permissions');
    //         const data = await res.json();
    //         setClientPermissions(data.permissions);
    //     };
    //     fetchClientPermissions();
    // }, []);
    // console.log(`Get from server side: ${clientPermissions  }`)

    return (
        <div>
            <h1>权限控制示例</h1>

            {/* 服务端渲染：仅展示服务端获取的权限 */}
            <div>
                <h2>服务端权限数据</h2>
                <pre>{JSON.stringify(serverPermissions, null, 2)}</pre>
            </div>

            {/* 客户端动态渲染：结合服务端和客户端数据 */}
            <div>
                <h2>客户端权限数据</h2>
                {/* <pre>{JSON.stringify(clientPermissions, null, 2)}</pre> */}
            </div>

            {/* 权限控制组件：根据权限动态显示 */}
            {/* {serverPermissions.includes('edit_posts') && (
                <button>编辑文章</button>
            )} */}
            <PromptManagementPage data={data} />
        </div>
    );
};

// 通过 getServerSideProps 在服务端获取权限数据
// export const getServerSideProps: GetServerSideProps = async () => {
//     const res = await fetch('http://localhost:3000/api/permissions');
//     const { permissions } = await res.json();
//     return { props: { serverPermissions: permissions } };
// };

export default HomePage;