"use client";
import { useState } from "react";


export function PromptManagementPage({ data }: any) {
    const [formData, setFormData] = useState({
        name: "",
        description: "",
        content: "",
        category: "",
    });
    return (<div>
        child comp {JSON.stringify(data)}
    </div>)
}