'use server'
import { cookies } from 'next/headers';
import PromptManagementPage from './(test)/prompts/page'
export default async function DashboardPage() {

  console.log("asda")
  const cookieStore = await cookies();
  console.log(JSON.stringify(cookieStore.getAll()))
  console.log(JSON.stringify(global.cacheUser.get("43")))
  return <PromptManagementPage></PromptManagementPage>;
}
