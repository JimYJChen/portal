import { NextResponse } from "next/server";

export async function GET(request: Request) {
    const responseHeader = new Headers();

    responseHeader.append("location", "/")
    global.cacheUser.set("43", "SD")
    return new Response(`Hello, ${request.url}!`, { status: 302, headers: responseHeader });
}
