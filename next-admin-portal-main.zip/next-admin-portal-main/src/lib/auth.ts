// lib/auth.ts
import { ROUTE_PERMISSIONS } from '../config/route-auth'
import { NextRequest, NextResponse } from 'next/server';

export const checkRoutePermission = (request: NextRequest): boolean => {
    const { pathname } = request.nextUrl

    // 获取匹配的路由配置
    const matchedRoute = Object.keys(ROUTE_PERMISSIONS).find(route => {
        // 处理动态路由匹配
        if (route.includes('[')) {
            const routeRegex = new RegExp(
                `^${route.replace(/\[.*?\]/g, '([^/]+)')}$`
            )
            return routeRegex.test(pathname)
        }
        return pathname === route
    })

    // 无需权限的路由
    if (!matchedRoute) return true

    // 获取需要的权限
    const requiredPermissions = ROUTE_PERMISSIONS[matchedRoute]

    // 获取用户权限（根据你的认证方案实现）
    const userPermissions = getCurrentUserPermissions()

    // 权限校验逻辑
    return requiredPermissions.every(perm =>
        userPermissions.includes(perm))
}

const getCurrentUserPermissions = (): string[] => {

    return ["USER_READ"];
}
