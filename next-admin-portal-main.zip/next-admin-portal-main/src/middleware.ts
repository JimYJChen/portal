import { NextRequest, NextResponse } from 'next/server';
import { checkRoutePermission } from "./lib/auth"
export function middleware(request: NextRequest) {
    // 1. 获取请求路径
    const { pathname } = request.nextUrl
    console.log("###########Here ! ##############")
    // 2. 跳过不需要鉴权的路径
    if (pathname.startsWith('/_next') ||
        pathname.startsWith('/static') ||
        pathname.startsWith('/api/auth')) {
        return NextResponse.next()
    }
    
    // 3. 权限校验逻辑
    const hasPermission = checkRoutePermission(request)

    // 4. 无权限处理
    if (!hasPermission) {
        return NextResponse.redirect(new URL('/403', request.url))
    }

    return NextResponse.next()
}

// 匹配所有路由
export const config = {
    matcher: '/:path*',
}
