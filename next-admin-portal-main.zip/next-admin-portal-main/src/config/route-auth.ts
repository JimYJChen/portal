// config/routes.ts
export const ROUTE_PERMISSIONS: Record<string, string[]> = {
    '/dashboard': ['DASHBOARD_VIEW'],
    '/evaluation': ['USER_READ'],
    '/users/create': ['USER_WRITE'],
    '/settings': ['ADMIN_ACCESS'],
    '/products': ['PRODUCT_MANAGEMENT'],
    '/products/[id]/edit': ['PRODUCT_EDIT']
}