import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  devIndicators: {
    appIsrStatus: false,
    buildActivity: true,
  },

  typescript: {
    // 忽略 TypeScript 类型检查错误
    ignoreBuildErrors: true,
  },
  eslint: {
    // 忽略 ESLint 检查错误
    ignoreDuringBuilds: true,
  },
  experimental: {
    nodeMiddleware: true,
  },
  runtime: 'nodejs',
};

export default nextConfig;
